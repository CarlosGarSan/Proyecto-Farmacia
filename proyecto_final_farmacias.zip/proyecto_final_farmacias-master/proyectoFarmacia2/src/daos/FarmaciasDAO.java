package daos;

import modelos.Farmacia;

public interface FarmaciasDAO {

	Farmacia obtenerDatosFarmacia(String email);
	
}
